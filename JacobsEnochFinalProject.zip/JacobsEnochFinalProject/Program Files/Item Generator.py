# import all the things
import tkinter as tk
from tkinter import *
from tkinter import ttk
import tkinter.font as font
import ModularOptions as op



#==================================== SELECTED ITEMS =========================================
""" This Code keeps track of the attributes of the currently selected item. """
#=============================================================================================

# stores what a new item looks like
blank_item = {
    "ItemName"            : "",
    "ItemType"            : "",

    "PrefixAugment"       : "None",
    "PrefixPower"         : 0, 
    "PrefixVariation"     : "None",

    "SuffixAugment"       : "None", 
    "SuffixPower"         : 0, 
    "SuffixVariation"     : "None",

    "TertiaryAugment"     : "None", 
    "TertiaryPower"       : 0, 
    "TertiaryVariation"   : "None",

    "TriggerAugment"      : "None", 
    "TriggerPower"        : 0, 
    "TriggerVariation"    : "None"
}

# stores the current sellected item
selected_item = blank_item.copy()

# stores the slot type that the user is currently modifying
selected_slot = "Prefix"



#================================= MISCELLANEOUS FUNCTIONS ===================================
""" Holds some basic functions. """
#=============================================================================================

def getAugment(name):
    """ Fetches an augment object from the string of its name. """
    for Aug in op.Enhancements:
        if name == Aug.name: return Aug


def getPowerLevel(powerLevel, desiredDataType="int"):
    """ Converts a power level back and forth between a string for display or an int for calculations. 
    First argument is the power level to convert, second is what you want to convert it into. Int by default. """
    if desiredDataType == "int": return int(powerLevel.lstrip("Power Level: "))
    if desiredDataType == "str": return f"Minimum level: {powerLevel}"


def check_for_attunement():
    """ Checks if any of the augments used requires attunement. If one does then it is noted on the selected item. """
    for slot in ('PrefixAugment', 'SuffixAugment', 'TertiaryAugment', 'TriggerAugment'): # loops through each augment
        if getAugment(selected_item[slot]).attunement == True: return True # if one is true return true
        else: return False # if not return false 


def getMinimumLevel():
    """ Calculates and returns the minimum level of an item. """
    minimum_level = 0 # start at 0
    for x in ('Prefix', 'Suffix', 'Tertiary', 'Trigger'): # for each augment 
        minimum_level += selected_item[x + "Power"] # add that augment's power level to minimum level
    return minimum_level # return minimum level


def getSlotBuildCost(slot): # takes the name of the augment in the slot you are checking
    """ Calculates the build cost of an augment. """
    aug = getAugment(selected_item[slot + "Augment"]) 
    cost = aug.costToBuild[0] + (getMinimumLevel() * aug.costToBuild[1]) # Calculate inital cost + (the scaling cost * the minimum level)
    return cost # return the cost


def getItemBuildCost(): # get the cost to build the entire item
    """ Gets the total cost of every augment in an item """
    cost = 0 # initialize cost to 0 
    for x in ['Prefix', 'Suffix', 'Tertiary', 'Trigger']: cost += getSlotBuildCost(x) # add the cost of each augment in each slot
    return cost # return the total


def copySelectedItem(from_, to_):
    """ Copies one version of an item to another. """
    for item in [ 
        "ItemName", "ItemType", "PrefixAugment", "PrefixPower",
        "PrefixVariation", "SuffixAugment", "SuffixPower", "SuffixVariation", "TertiaryAugment",
        "TertiaryPower", "TertiaryVariation", "TriggerAugment", "TriggerPower", "TriggerVariation"]:
        to_[item] = from_[item]



#===================================== SCREEN BASICS =========================================
""" Handles the window and the current high level state of the program. """
#=============================================================================================

# create the base window 
window = tk.Tk()
window.title("Item Generator Program")
window.geometry("958x562")
window.configure(bg='#555')
window.iconbitmap('images/favicon.ico')

# define / add the header
header = LabelFrame(window, bg="#999", width="1000", height="40")
header.grid(row=0, column=0, columnspan=3) 
# define / add the leftside frame
leftside = LabelFrame(window, bg="#999", width="325", height="560")
leftside.grid(row=1, column=0) 
# define / add the middle frame
middle = LabelFrame(window, bg="#999", width="350", height="560")
middle.grid(row=1, column=1)
# define / add the rightside frame
rightside = LabelFrame(window, bg="#999", width="325", height="560")
rightside.grid(row=1, column=2)

def updateState():
    """ Updates the current state of the program to show any changes. """
    resetInvalidDDMSelections()
    updateimage()
    updateCostBox()    
    updateNameplate()
    updateItemDescription()



#======================================= HEADER TABS =========================================
""" Handles the header tabs which switch from one page of the program to the next. """
#=============================================================================================

def clearTab():
    """ Clear Tabs function to clean the screen whe tabs are clciked. """
    for item in [ CompletedItemsDispaly, ModifyButton, SalvageButton, TotaCostBox, AugmentCostBox, 
        ItemTypeOptionDDM, AugmentOptionDDM, PowerOptionDDM, VariationOptionDDM,
        SelectPrefix, SelectSuffix, SelectTertiary, SelectTrigger, CreateButton ]:
        item.grid_forget()


def clickCompletedItemsTab():
    """ Switches the screen to the completed items page when the completed items tab is clicked. """
    clearTab() # clear widgets
    showCompletedItemsList() # build the Completed Items List
    showModifyButton() # build the Modify Button
    showSalvageButton() # build the Salvage Button
    NewItemTab.config(state="normal") # enable the New Item Tab
    CompletedItemsTab.config(state="disabled") # disable the Completed Items Tab


# Define Create New Item Tab function on click
def clickCreateNewItemTab():
    """ Switches the screen to the create new item page when the create new item tab is clicked. """
    clearTab() # clear widgets 
    showDDMs() # build the dropdown menus
    showSlotSelection() # build the Slot Selection      
    showCostBoxes() # build the cost display
    showCreateButton() # build the Create Button 
    CompletedItemsTab.config(state="normal") # enable the Completed Items Tab
    NewItemTab.config(state="disabled") # disable the New Item Tab


# Define and add Completed Items Tab 
CompletedItemsTab = Button(header, text="Completed Items", padx=25, command=clickCompletedItemsTab)
CompletedItemsTab.grid(row=0, column=1, padx=(0,360))

# Define and add Create New Item Tab
NewItemTab = Button(header, text="Create New Item", padx=25, command=clickCreateNewItemTab)
NewItemTab.grid(row=0, column=0, padx=(295, 1))



#======================================= COST BOXES ==========================================
""" Handles the lables which display the cost of items. """
#=============================================================================================

def updateCostBox():
    """ Updates what's displayed in the Cost Boxes. """
    # create the strings to be displayed.
    AugmentCost = "Augment Cost: " + str(getSlotBuildCost(selected_slot)) + " gold"
    TotaCost = "Tota Cost: " + str(getItemBuildCost()) + " gold"
    # configure those strings to their respective labels   
    AugmentCostBox.config(text=AugmentCost)
    TotaCostBox.config(text=TotaCost)
    

# define cost boxes
AugmentCostBox = Label(leftside, text="Augment Cost: 0 gold", bg="#fff", width=30, pady=5)
TotaCostBox = Label(leftside, text="Total Cost: 0 gold", bg="#fff", width=30, pady=5)

def showCostBoxes():
    """ Builds the Cost Boxes """
    AugmentCostBox.grid(row=8, column=0, pady=(20, 0))
    TotaCostBox.grid(row=9, column=0, pady=(0, 65))



#==================================== DROPDOWN MENUS =========================================
""" Handles the dropdown menus that are used to select properties of the item. """
#=============================================================================================

def selectedItemSanityCheck():
    """ Ensures that selected augment, power, and variation are valid. If not it defaults them to a new value. """
    # Loops through each slot 
    for slot in ["Prefix", "Suffix", "Tertiary", "Trigger"]: 
        # define the augment that we are working with for this loop
        aug = getAugment(selected_item[slot + "Augment"]) 
        # if the item type is not a valid one reset everything
        if selected_item["ItemType"] not in aug.validItemTypes: 
            selected_item[slot + "Augment"] = "None"
            selected_item[slot + "Power"] = 0
            selected_item[slot + "Variation"] = "None"
            continue
        # if the power is not valid one reset power
        if selected_item[slot + "Power"] not in aug.power: 
            selected_item[slot + "Power"] = list(aug.power.keys())[0]
        # if the variation is not valid one reset variation
        if selected_item[slot + "Variation"] not in aug.variations: 
            selected_item[slot + "Variation"] = list(aug.variations.keys())[0]


def resetInvalidDDMSelections():
    """ sanity check that resets selections that are no longer valid """
    # ensure each drop down menus is set to the current sellection 
    ItemTypeOptionDDM.set(selected_item["ItemType"])
    AugmentOptionDDM.set(selected_item[selected_slot + "Augment"])
    PowerOptionDDM.set(selected_item[selected_slot + "Power"])
    VariationOptionDDM.set(selected_item[selected_slot + "Variation"])
    # create a list of valid augment, power, and variation options based on current selection 
    augs = getDropdownOptions("Augment")
    pows = getDropdownOptions("Power")
    varis = getDropdownOptions("Variation")
    # loop through each dropdown menu
    for DDM, opts in zip([AugmentOptionDDM, PowerOptionDDM, VariationOptionDDM], [augs, pows, varis]):
        DDM.config(value = opts) # append the appropriate new list of options
        if DDM.get() not in opts: DDM.current(0) # if the current selection is not a valid option
                                                 # reset it to the first option available
    # set power level to the string value of its current selection
    PowerOptionDDM.set(getPowerLevel(selected_item[selected_slot + "Power"], "str"))



def getDropdownOptions(dropDownType): 
    """ Returns a list of options for the creation of the dropdown menus. 
    We pass a string in as an argument to tell us which dropdown menu we are getting options for. """
    # first check that everything is correct
    selectedItemSanityCheck() 
    augment = getAugment(selected_item[selected_slot + "Augment"]) # define the augment that we are working with
    options = [] # define an empty list to append options to

    # item type: loop through item types and append everything but the first one.
    # Since it is reserved for "Blank", which is the empty screen used for new items.
    if dropDownType == "ItemType": 
        for item in op.item_types[1:]: options.append(item) 
    # augment: loop through the list of Enhancements
    # if the option is valid for the slot and the item type append it to options
    if dropDownType == "Augment":
        for aug in op.Enhancements: 
            if selected_slot in aug.validSlot and selected_item["ItemType"] in aug.validItemTypes: 
                options.append(aug.name) 
    # power level: convert the power level to a string and append it
    if dropDownType == "Power": 
        for pow in augment.power: options.append("Power Level: " + str(pow))
    # variation: append variations
    if dropDownType == "Variation": 
        for entry in augment.variations: options.append(entry)
    # Return the list of options
    return options 


def clickDropdown(letter):
    """ When a drop down option is clicked, its corresponding value for 'Selected_Item' is updated. """
    # depending on which drop down menu is clicked, update the selected item value
    if letter == "T": selected_item["ItemType"] = ItemTypeOptionDDM.get()
    if letter == "A": selected_item[selected_slot + "Augment"] = AugmentOptionDDM.get()
    if letter == "P": selected_item[selected_slot + "Power"] = getPowerLevel(PowerOptionDDM.get())
    if letter == "V": selected_item[selected_slot + "Variation"] = VariationOptionDDM.get()
    # update the state of the program to reflect any changes
    updateState()


##### Define Dropdowns #####
# Item Type Dropdown 
ItemTypeOptionDDM = ttk.Combobox(leftside, state="readonly",
value = getDropdownOptions("ItemType"), width=25, font="Helvetica 11")
ItemTypeOptionDDM.bind("<<ComboboxSelected>>", lambda x: clickDropdown("T"))
# Augment Dropdown 
AugmentOptionDDM = ttk.Combobox(leftside, state="readonly",
value = getDropdownOptions("Augment"), width=25, font="Helvetica 11")
AugmentOptionDDM.bind("<<ComboboxSelected>>", lambda x: clickDropdown("A"))
AugmentOptionDDM.current(0)
# Power Dropdown 
PowerOptionDDM = ttk.Combobox(leftside, state="readonly",
value = getDropdownOptions("Power"), width=25, font="Helvetica 11")
PowerOptionDDM.bind("<<ComboboxSelected>>", lambda x: clickDropdown("P"))
PowerOptionDDM.current(0)
# Variation Dropdown 
VariationOptionDDM = ttk.Combobox(leftside, state="readonly",
value = getDropdownOptions("Variation"), width=25, font="Helvetica 11")
VariationOptionDDM.bind("<<ComboboxSelected>>", lambda x: clickDropdown("V"))
VariationOptionDDM.current(0)

def showDDMs():
    """ Builds Dropdown menus """
    ItemTypeOptionDDM.grid(row=0, column=0, pady=(23, 20), padx=20)
    AugmentOptionDDM.grid(row=5, column=0)
    PowerOptionDDM.grid(row=6, column=0, pady=15)
    VariationOptionDDM.grid(row=7, column=0, pady=(0, 40))



#============================== AUGMENT SLOT SELECTION BUTTONS ===============================
""" Handles the buttons which change what augment slot you have selected. """
#=============================================================================================

# Selection Buttons on clcik function
def clickSlotSelect(slotType):
    """ Changes the augment slot selection based on which button was clicked. """
    global selected_slot
    selected_slot = slotType
    resetInvalidDDMSelections()
    updateCostBox()


# Selection Buttons Variabe
# ((( There is probably a better way of doing this but I am tired and this works... )))
FakeSelectedEnchant = StringVar()
FakeSelectedEnchant.set("Prefix")
# Define Selection Buttons
SelectPrefix = Radiobutton(leftside, text="Item Prefix", width=24,
    variable=FakeSelectedEnchant, value="Prefix", command=lambda: clickSlotSelect("Prefix"))
SelectSuffix = Radiobutton(leftside, text="Item Suffix", width=24,
    variable=FakeSelectedEnchant, value="Suffix", command=lambda: clickSlotSelect("Suffix"))
SelectTertiary = Radiobutton(leftside, text="Item Tertiary", width=24,
    variable=FakeSelectedEnchant, value="Tertiary", command=lambda: clickSlotSelect("Tertiary"))
SelectTrigger = Radiobutton(leftside, text="Item Trigger", width=24,
    variable=FakeSelectedEnchant, value="Trigger", command=lambda: clickSlotSelect("Trigger"))

def showSlotSelection():
    """ Builds Selection Buttons """
    SelectPrefix.grid(row=1, column=0, pady=(20, 3), padx=(34, 35))
    SelectSuffix.grid(row=2, column=0, pady=3)
    SelectTertiary.grid(row=3, column=0, pady=3)
    SelectTrigger.grid(row=4, column=0, pady=(3, 40))



#================================== COMPLETED ITEMS DISPLAY ==================================
""" Handles the completed items list, as well as switching selection from item to the next. """
#=============================================================================================

# update the Completed Items Dispaly
def updateCompletedItemsDispaly():
    """ Updates the contents of the completed items display """
    CompletedItemsDispaly.delete(0, "end") # delete current list
    for item in Completed_Items: # rebuild list
        CompletedItemsDispaly.insert("end", generateName(item)) 


def clickCompletedItemsDispaly(args):
    """ Handles what happens when a new item is selected from the completed items list. """
    if CompletedItemsDispaly.curselection() != (): # assume that something was actually selected
        # get the item selection from the list of completed items
        selected = Completed_Items[ CompletedItemsDispaly.curselection()[0] ]
        # current selected item becomes equal to the selection
        copySelectedItem(selected, selected_item)  
        # update the program to reflect this change
        updateState()


# create an array to hold completed items
Completed_Items = []
# define completed items Dispaly
CompletedItemsDispaly = Listbox(leftside, width=39, height=28)
CompletedItemsDispaly.bind("<<ListboxSelect>>", clickCompletedItemsDispaly)

# add completed items Dispaly
def showCompletedItemsList(): CompletedItemsDispaly.grid(row=0, column=0, pady=(25, 0), padx=(14, 13))



#====================================== CREATE BUTTON ========================================
""" Handles the button that adds items to the completed items list. """
#=============================================================================================

def ConfirmCreate():
    """ Exports the current item to the completed items list. """
    new_item = {} # create new empty item as a dictionary
    copySelectedItem(selected_item, new_item) # copy the selected item onto the new item
    Completed_Items.append(new_item) # append the new item to the completed items list
    copySelectedItem(blank_item, selected_item) # reset the selected item to a blank state
    updateCompletedItemsDispaly() # update the state of the completed items list
    updateState() # show the new state of the program
    

def clickCreateButton():
    """ Handles the click event of the create item button. """
    try: Popup.destroy() # close the popup if it is already open
    except: pass
    if selected_item["ItemType"] != "": # if there is no item, do nothing
        PopupWindow("Create") # otherwise bring up a popup window asking if they are sure


# Define the create button
bigFont = font.Font(family='Helvetica', size=25)
CreateButton = Button(middle, text="Create", width=9, font=bigFont, command=clickCreateButton)
# add the create button
def showCreateButton(): CreateButton.grid(row=3, column=0, padx=25, pady=24)



#====================================== SALVAGE BUTTON =======================================
""" Handles the button that removes items from the completed items list. """
#=============================================================================================

def ConfirmSalvage():
    """ Removes the selected item from the completed items list. """
    selected = CompletedItemsDispaly.curselection()[0] # define what is selected
    Completed_Items.pop(selected) # remove it
    copySelectedItem(blank_item, selected_item) # reset the selected item to a blank state
    updateCompletedItemsDispaly() # update the state of the completed items list
    updateState() # show the new state of the program


def clickSalvageButton():
    """ Handles the click event of the salvage item button. """
    try: Popup.destroy() # close the popup if it is already open
    except: pass
    if CompletedItemsDispaly.curselection() != (): # if there is no item selected, do nothing
        PopupWindow("Salvage") # otherwise bring up a popup window asking if they are sure


# define the salvage button
SalvageButton = Button(middle, text="Salvage", width=9, font=bigFont, command=clickSalvageButton)
# add the salvage button
def showSalvageButton(): SalvageButton.grid(row=3, column=0, padx=25, pady=24)



#====================================== POPUP WINDOW =========================================
""" Handles the popup window that asks for confirmation from the user. """
#=============================================================================================  

def PopupWindow(popupType):
    """ Open the popup message box and ask for confirmation from the user. """

    submitName() # Submit the name if it had not been already
    def popupConfirm(choice):
        """ If they choose yes, run an event based on the choice, and close the window. """
        Popup.destroy()
        CreateButton.config(state="normal")
        if choice == "Y" and popupType == "Salvage": ConfirmSalvage()
        if choice == "Y" and popupType == "Create": ConfirmCreate()
        if choice == "Y" and popupType == "Export": confirmExport()

    # create a message to display based on what type of popup it is
    if popupType == "Salvage":
        try: salvageAmount = int(getItemBuildCost() / 2.50)
        except: salvageAmount = 0
        message = f"Are you sure want to salvage {generateName()} for {salvageAmount} gold?"
    if popupType == "Create": message = f"Are you sure want to build {generateName()} for {getItemBuildCost()} gold?"
    if popupType == "Export": message = f"Are you sure want to export {generateName()} to a text document?"

    # define / add the popup window
    global Popup
    Popup = Toplevel(window) 
    Popup.title("Confirm " + popupType)
    PopupMessage = Label(Popup, text=message, wraplength=300, justify="center", padx=30, pady=20) 
    PopupMessage.grid(row=0, column=0, columnspan=2)

    # define / add the yes button 
    yesButton = Button(Popup, text="Yes", width=6, command=lambda: popupConfirm("Y"))
    yesButton.grid(row=1, column=0, pady=(0, 20))
    # define / add the no button 
    noButton = Button(Popup, text="No", width=6, command=lambda: popupConfirm("N"))
    noButton.grid(row=1, column=1, pady=(0, 20))



#====================================== MODIFY BUTTON ========================================
""" Handles the Modify Button. """
#============================================================================================= 

def clickshowModifyButton():
    """ Deletes an item from the completed items list and immediately puts you back on 
    the item creation screen with that item selected """
    if CompletedItemsDispaly.curselection() != (): # confirm that something is selected
        selected = CompletedItemsDispaly.curselection()[0] 
        Completed_Items.pop(selected) # delete the selected item
        updateCompletedItemsDispaly() # update the display
        clickCreateNewItemTab() # move to the create new tab for editing


# define the Modify Button
ModifyButton = Button(leftside, text="Modify Item", padx=12, command=clickshowModifyButton)
# add the Modify Button
def showModifyButton(): ModifyButton.grid(row=1, column=0, padx=20, pady=(0, 23))



#===================================== ITEM NAMEPLATE ========================================
""" Handles the logic behind the name plate and giving items custom names. """
#============================================================================================= 


def generateName(item=selected_item):
    """ Gets the name of an item, or generates a name based on the items properties  
        uses the current item selection unless specified  """
    Name = item["ItemName"] # initializes the name variable as the items name 
    if Name == "": # if that name is an empty string it creates one of its own
        # adds the Prefix name, uses the Variation name first unless it is "None"
        if item["PrefixVariation"] == "None":
            if item["PrefixAugment"] != "None": Name += item["PrefixAugment"] + " "
        else: Name += item["PrefixVariation"] + " " 
        # adds the item type in the middle
        Name += item["ItemType"]
        # adds the Suffix name, uses the Variation name first unless it is "None"
        if item["SuffixVariation"] == "None": 
            if item["SuffixAugment"] != "None": Name += " of " + item["SuffixAugment"]
        else: Name += " of " + item["SuffixVariation"]
    return Name # returns the name


# function that updates the name plate
def updateNameplate(): ItemNamePlate.config(text=generateName())


def clickNameplate(): 
    """ function that runs when the name plate is clicked  """
    ItemNamePlate.grid_forget() # clears the nameplate
    ItemEntryPrompt.grid(   row=0, column=0, padx=(116, 117), pady=(18, 0)) # adds the name prompt
    ItemEntry.grid(         row=1, column=0, pady=(0, 28)) # adds the name entry box


def submitName(args=""):
    """ function that runs when the name entry is submited """
    ItemEntryPrompt.grid_forget() # clear name prompt
    ItemEntry.grid_forget() # clear entry box
    ItemNamePlate.grid(row=1, column=0, padx=23, pady=(23, 22)) # adds the nameplate back
    selected_item["ItemName"] = ItemEntry.get() # sets the selected item's name to the name entered
    updateNameplate() # updates the nameplate
    updateItemDescription() # updates the item description 

# define and add the name plate
ItemNamePlate = Button(middle, text="", width=42, height=2, command=clickNameplate)
ItemNamePlate.grid(row=1, column=0, padx=23, pady=(23, 22))

# define the name entry prompt
ItemEntryPrompt = Label(middle, text="Press Enter to submit", bg="#999")
ItemEntry = Entry(middle, width=42, validate="focusout", validatecommand=submitName)
ItemEntry.bind("<Return>", submitName)



#======================================== IMAGE BOX ==========================================
""" Handles the item image box which displays the item image. """
#============================================================================================= 

def updateimage():
    """ function that changes the image in response to events """
    ImageName = selected_item["ItemType"] # get the name of the selected item type  
    if ImageName == "": ImageName = "Blank" # if that name is an empty string, replace it with "Blank"
    ItemImageBox.config(text=ImageName) # set alternative text to the image name
    ItemImage = PhotoImage(file="images/" + ImageName + ".png") # turn that name into a Photo Image object
    ItemImageBox.config(image=ItemImage) # set the image as the image for the image box
    ItemImageBox.image=ItemImage # update the image


# create / add the image box 
ItemImage = PhotoImage(file="images/Blank.png")
ItemImageBox = Label(middle, image=ItemImage, text="Blank", bg='#222')
ItemImageBox.grid(row=2, column=0)



#================================ ITEM DESCRIPTION BOX =======================================
""" Handles the item description box which displays the item description. """
#============================================================================================= 

def getItemDescription():
    """ Creates a description for the currently selected item. """
    item_description = generateName() # sarts by creating a string with the items name
    if selected_item["ItemType"] != "": 
        # if not completely empty add the minimum level and item type
        item_description += f"\nMinimum level: {getMinimumLevel()} "
        item_description += selected_item['ItemType'] 
    # if the item requires attunement add that to the description
    if check_for_attunement(): item_description += "\nRequires Attunement"
    # loop through the augment slots
    for x in ('Prefix', 'Suffix', 'Tertiary', 'Trigger'):
        # add the augment's description to the items description
        if selected_item[x + "Augment"] != "None": item_description += "\n\n" + createAugmentDescription(x)
    # return the completed description 
    return item_description


def createAugmentDescription(slot_type):
    """ Creates a description for an augment. """
    # get the augment from the slot, including its power level, variation, and base description
    augment = getAugment(selected_item[slot_type + "Augment"])
    power = augment.power[selected_item[slot_type + "Power"]]
    variation = selected_item[slot_type + "Variation"]
    base_description = augment.description
    # if there is a variation get its aspect and flavor text
    if selected_item[slot_type + "Variation"] != "None":
        flavortext = augment.variations[variation]['flavortext']
        aspect = augment.variations[variation]['aspect']
    # if not use the augments base name instead
    else:
        flavortext = ""
        aspect = ""
        variation = selected_item[slot_type + "Augment"]
    # make a subheading that gets the slot and name of the augment filling it
    name = slot_type + ": " + variation\
    # add a linebreak, and the description before replacing the stand in keywords in the augments description 
    # with the appropriate text snippets from the variation and power level 
    name = name + "\n" + base_description\
            .replace("[flavortext]", flavortext)\
            .replace("[aspect]", aspect)\
            .replace("[power]", power)\
            .replace("[itemType]", selected_item['ItemType'])\
            .replace("  ", " ")\
            .lstrip(" ")
    return name # return the name


def updateItemDescription():
    """ updates the item description box """
    ItemDescription = getItemDescription() # get description 
    ItemDescriptionBox.config(text=ItemDescription) # set description 
    ItemDescriptionBox.text=ItemDescription # update description 


# define / add the Item Description Box
ItemDescriptionBox = Label(rightside, 
text="", width=35, height=29, justify="left", anchor=NW, wraplength=250, padx=16, pady=10)
ItemDescriptionBox.grid(row=0, column=0, padx=(25, 24), pady=(25, 0))



#============================== EXPORT TO TEXT DOCUMENT BUTTON ===============================
""" Handles the export button which exports an item's description to a text box. """
#=============================================================================================

def confirmExport(): 
    """ Saves the item description to a text document. """
    with open("../Saved Items/" + generateName() + ".txt", 'w') as f: f.write(getItemDescription())


def clickExportButton():
    """ Handles the click function of the export button which opens a popup asking for confirmation. """ 
    try: Popup.destroy() # close the popup if it is already open
    except: pass
    if "\n" in getItemDescription(): PopupWindow("Export") # export file


# define / add the export button
exportTextButton = Button(rightside, text="Export to Text Document", padx=10, command=clickExportButton)
exportTextButton.grid(row=1, column=0, padx=20, pady=(0, 16))



#=============================================================================================
#=============================================================================================

# start the main loop and open the program on the New Item page
clickCreateNewItemTab()
window.mainloop()